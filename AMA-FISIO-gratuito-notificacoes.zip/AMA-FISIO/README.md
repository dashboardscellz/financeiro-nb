# AMA FISIO — Cadastro de clientes, agenda e lembretes no site

**Versão 1.2 — sem envio de e-mails de agendamento, sem WhatsApp, sem serviços de mensagens, sem Cloud Functions e compatível com Firebase Spark (plano gratuito).**

Aplicação em português brasileiro para computadores, tablets e celulares. A prioridade é **cadastro de clientes**; a agenda é um recurso adicional, com notificações opcionais exibidas **apenas após entrar no site**. A logo original da AMA FISIO está em `docs/assets/logo-ama-fisio.png`.

> **Atenção:** O áudio inicialmente anexado ainda não foi transcrito com confiabilidade. Confira os campos do cadastro com a descrição original antes de registrar pacientes reais. O projeto é uma implementação inicial, não um prontuário eletrônico certificado nem uma garantia de conformidade automática com a LGPD.

## O que mudou nesta versão

- Removidos **Resend**, API de e-mail, Cloud Functions, arquivos do backend, configuração e checkbox de envio de confirmações de agendamento.
- Acrescentado **sininho de notificações 🔔** na barra superior com contador de lembretes não lidos.
- Ao criar ou editar uma consulta, escolha **Não lembrar**, **No dia do atendimento**, **1 dia antes** ou **2 dias antes**. A opção padrão é **Não lembrar**, evitando avisos indesejados.
- O sino abre a central com duas abas: **Lembretes** (avisos vencidos ainda não lidos) e **Hoje** (atendimentos do dia). Cada lembrete tem **Ver agendamento** e **Marcar como lido**; também existe **Marcar todos como lidos**.
- As leituras são independentes **por usuário autorizado** e persistem no Firestore. Remarcar uma consulta (ou mudar seu prazo de lembrete) faz o aviso voltar quando a nova data de lembrete chegar.
- **Com o site fechado não chega qualquer notificação**. Ao retornar, o site consulta a agenda e mostra os avisos aplicáveis. Quando o site está aberto, a tela atualiza periodicamente. Não há push, SMS, navegador, WhatsApp, e-mail ou serviço externo.
- Agendamentos **concluídos/cancelados** não aparecem como lembretes pendentes. O lembrete aparece a partir do início do dia programado até o fim previsto da consulta, enquanto o agendamento estiver ativo. Todos os compromissos do dia continuam acessíveis na aba **Hoje**.

**Importante sobre e-mails:** somente os e-mails de **criação/verificação de usuário e recuperação de senha** continuam disponíveis como recursos nativos de segurança do Firebase Authentication. Não existem e-mails de consulta ou lembretes aos clientes.

## Estrutura

```text
AMA-FISIO/
├── docs/
│   ├── index.html                 # Site
│   ├── app.js                     # Telas, agenda e notificações internas
│   ├── styles.css                 # Layout responsivo e sino de notificações
│   ├── config.js                  # Chaves públicas Firebase (preencher)
│   ├── config.example.js          # Modelo de configuração
│   └── assets/logo-ama-fisio.png # Logo enviada
├── firestore.rules                # Permissões de cadastros, agenda e leituras individuais
├── firebase.json                  # Firebase Hosting + Firestore Rules, SEM Functions
├── scripts/bootstrap-master.mjs   # Instala a conta mestre via Admin SDK
├── package.json
├── PROMPT-DE-APERFEICOAMENTO.md
└── README.md
```

## Configuração em Firebase (plano Spark)

1. Crie um projeto no [Console Firebase](https://console.firebase.google.com/) e permaneça no **plano Spark**, sem adicionar conta de faturamento. Ative **Authentication → Sign-in method → E-mail/senha**.
2. Ative **Cloud Firestore**. Selecione a região adequada antes de iniciar. O banco Firestore cobra por uso somente em projetos com opção de pagamento habilitada; no Spark, aplica-se a cota gratuita e o serviço pode ser interrompido ao superar os limites.
3. Registre um aplicativo **Web** no Firebase e copie os campos públicos `apiKey`, `authDomain`, `projectId`, `appId`, `messagingSenderId` (e `storageBucket`, se fornecido) para `docs/config.js`. Essas **configurações públicas não são senhas**; as regras do banco controlam os acessos. Configure `masterEmail` com o e-mail escolhido para a administradora e `demoEnabled: false`.
4. Crie a conta mestre em ambiente de confiança usando o arquivo `scripts/bootstrap-master.mjs`. Não deixe senhas ou chaves de conta de serviço no site nem no GitHub. O nome de login **Amanda Marinho** será traduzido para o e-mail informado em `masterEmail`.
5. Instale o Node.js e execute na pasta do projeto:
   ```bash
   npm install
   npx firebase login
   npx firebase use --add
   npm run deploy
   ```
   O deploy publica o **Hosting** e as **regras do Firestore**. Não inclui Cloud Functions.
6. No Firebase Authentication, em **Settings → Authorized domains**, inclua os domínios que realmente serão usados (Firebase e/ou GitHub Pages). Faça o primeiro acesso e teste cadastro, aprovação de colaboradores e regras de acesso.

### Conta mestre (sem publicar a senha)

O script de instalação exige `GOOGLE_APPLICATION_CREDENTIALS`, `MASTER_EMAIL` e `MASTER_PASSWORD` como variáveis de ambiente locais. No Windows PowerShell, um exemplo:

```powershell
$env:GOOGLE_APPLICATION_CREDENTIALS="C:\\caminho\\para\\conta-de-servico.json"
$env:MASTER_EMAIL="amanda@seudominio.com"
$env:MASTER_PASSWORD=Read-Host "Informe a senha da conta mestre"
npm run bootstrap:master
Remove-Item Env:MASTER_PASSWORD
```

É recomendável trocar a senha inicial por outra forte, de uso exclusivo, e restringir o acesso a qualquer chave de serviço.

### GitHub

O código completo pode ser mantido em um repositório **privado** do GitHub. O GitHub Pages pode hospedar `/docs` como site estático; o Firestore e Firebase Authentication continuam sendo responsáveis pelos dados e permissões. A publicação do código-fonte não deve incluir `.env`, chave de conta de serviço, dados reais de clientes ou senhas. A logo original é parte do site.

## Como usar os lembretes

1. Vá em **Agendamentos → Novo agendamento** (ou **Clientes → Agendar**).
2. Escolha um cliente, horário, profissional e situação.
3. Em **Lembrete dentro do site**, escolha `1 dia antes`, por exemplo, e salve.
4. Ao acessar o AMA FISIO no dia anterior, o sino 🔔 mostrará um número com os avisos pendentes. Clique nele para ver os lembretes, abrir o agendamento, marcar individualmente ou marcar todos como lidos.
5. Alterne para **Hoje** para consultar todas as consultas do dia, mesmo que não tenham lembrete. Clique em **Ver agenda de hoje** para filtrar a página de agendamentos.

**Regras:** lembretes não marcados permanecem pendentes entre acessos e dispositivos enquanto forem pertinentes; cada funcionário marca os próprios como lidos. Se a consulta mudar de data, hora ou cliente ou se o prazo do lembrete mudar, o registro de leitura da versão anterior não impede que a nova configuração avise novamente. Não há notificação fora do site.

## Testar a demonstração sem conectar o banco

`docs/config.js` vem como arquivo de exemplo, com `demoEnabled: true` para testar com **dados fictícios, somente na memória do navegador**, sem gravar clientes. Inicie um servidor HTTP local:

```bash
cd docs
python -m http.server 4173
```

Visite `http://localhost:4173`, clique em **Explorar demonstração**, entre na agenda e teste o sino. **Não use dados reais de pacientes no modo demonstração.**

## Limites e pontos de atenção

- O projeto pode permanecer no **Spark**. O Firebase oferece cotas gratuitas para Firestore/Hosting e autenticação por e-mail/senha, mas não garante disponibilidade ilimitada: o serviço pode parar ao atingir a cota. Consulte o uso no console.
- As notificações são **geradas localmente no navegador a partir dos registros consultados**. Não são tarefas programadas no servidor e não aparecem com o site fechado. Não se usa Storage nem Functions neste sistema.
- Em ambiente clínico, dados de saúde são **sensíveis pela LGPD**. Antes da operação real, revise finalidade, base legal, transparência, controle de acesso por necessidade, backup, retenção, segurança e plano para incidentes. O termo no formulário não dispensa análise jurídica.
- Na versão atual, membros **ativos** da equipe podem consultar e alterar todas as fichas de clientes e agendamentos; só a conta mestre aprova usuários, exclui cadastros e exporta CSV. Se usuários diferentes só devem ter acesso a certos clientes, as permissões precisam ser refinadas antes de usar dados reais.
- A checagem de conflitos de agenda na interface não substitui uma trava transacional para agendamentos concorrentes.
- Não há envio de e-mails de agendamento nem notificações de navegador, celular, SMS ou WhatsApp. Os avisos da agenda são visíveis somente dentro da plataforma.

## Referências oficiais

- [Planos gratuitos e limites Firebase](https://firebase.google.com/docs/projects/billing/firebase-pricing-plans)
- [Cloud Firestore — atualizações em tempo real](https://firebase.google.com/docs/firestore/query-data/listen?hl=pt-br)
- [Regras do Cloud Firestore](https://firebase.google.com/docs/firestore/security/rules-conditions)
- [Firebase Hosting](https://firebase.google.com/docs/hosting/quickstart)
- [Firebase Authentication](https://firebase.google.com/docs/auth/web/password-auth)
- [Lembretes configuráveis do Google Agenda](https://support.google.com/calendar/answer/37242?hl=pt-BR)
- [ANPD — proteção de dados](https://www.gov.br/anpd/)
