// COPIE este arquivo para config.js e insira as credenciais PÚBLICAS do seu aplicativo web Firebase.
// Essas chaves identificam o projeto; o controle real de acesso é feito pelas regras do Firestore.
// NUNCA inclua senhas, chaves privadas, service accounts ou GOOGLE_APPLICATION_CREDENTIALS aqui.
window.AMA_CONFIG = {
  firebase: {
    apiKey: 'COLE_SUA_API_KEY',
    authDomain: 'SEU-PROJETO.firebaseapp.com',
    projectId: 'SEU-PROJETO',
    appId: 'COLE_SEU_APP_ID',
    storageBucket: 'SEU-PROJETO.firebasestorage.app',
    messagingSenderId: 'COLE_SEU_SENDER_ID'
  },
  // O login com o nome "Amanda Marinho" traduz este nome para o e-mail abaixo.
  // Deve ser o mesmo MASTER_EMAIL informado ao script de instalação.
  masterEmail: 'amanda@SEU-DOMINIO.com',
  // Demonstração ilustrativa, SEM salvar dados reais. Desative em produção.
  demoEnabled: false
};
