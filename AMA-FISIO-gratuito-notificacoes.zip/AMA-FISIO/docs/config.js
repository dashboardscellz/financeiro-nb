// PREENCHA este arquivo ANTES de publicar. Não coloque senhas aqui.
window.AMA_CONFIG = {
  firebase: {
    apiKey: 'COLE_SUA_API_KEY',
    authDomain: 'SEU-PROJETO.firebaseapp.com',
    projectId: 'SEU-PROJETO',
    appId: 'COLE_SEU_APP_ID',
    storageBucket: 'SEU-PROJETO.firebasestorage.app',
    messagingSenderId: 'COLE_SEU_SENDER_ID'
  },
  masterEmail: 'amanda@SEU-DOMINIO.com',
  demoEnabled: true
};
