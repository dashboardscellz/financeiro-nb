# Prompt para aperfeiçoar o AMA FISIO sem custos de plano pago

Atue como arquiteto de software e designer especialista em sistemas simples de gestão de clientes, acessibilidade, Firebase Authentication, Cloud Firestore e proteção de dados pessoais sensíveis (LGPD).

Evolua o projeto **AMA FISIO**, respeitando rigorosamente:

- Prioridade em **cadastro e gestão de clientes**; agenda como função secundária. Manter a logo original em `docs/assets/logo-ama-fisio.png`, identidade visual verde/bege/coral, português brasileiro e design responsivo para computador, tablet e celular.
- Hospedar em **Firebase Hosting no plano gratuito Spark**, com fonte versionada no **GitHub**. Não exigir Blaze, Cloud Functions, provedores de e-mails externos, servidores próprios ou assinaturas.
- Não implementar **envio de e-mails para clientes, mensagens de WhatsApp, SMS, push notifications, notificações no sistema operacional ou alertas fora do site**. E-mails nativos do Firebase Authentication para acesso e recuperação de senha podem ser preservados.
- Na agenda, permitir **Lembrete dentro do site** com valores **Não lembrar** (padrão), **No dia**, **1 dia antes**, **2 dias antes**. O sistema mostra o **ícone de sino 🔔 na barra superior** com badge numérico apenas para lembretes pendentes; ao clicar abre a central com abas **Lembretes** e **Hoje**, ações **Ver agendamento**, **Marcar como lido**, **Marcar todos como lidos** e **Ver agenda de hoje**.
- Calcular os lembretes a partir dos agendamentos no Firestore quando o usuário entra ou o site está aberto; não agendar tarefas no backend. Mostrar o lembrete a partir da data escolhida até o fim previsto da consulta, desde que agendamento permaneça ativo; desconsiderar cancelados/concluídos. O aviso **não aparece com o site fechado** e nenhum aviso é enviado ao cliente.
- Manter estado de leitura **separado para cada usuário autorizado**, persistido em `users/{uid}/reminderReads/{appointmentId}` com regras que só permitam acesso pelo próprio usuário. Reabrir o aviso se o agendamento for alterado significativamente (data, horário, cliente ou antecedência).
- Login por e-mail/senha com conta mestre denominada **Amanda Marinho**, criada em Admin SDK com custom claim `master`, sem inserir senha no repositório. Colaboradores começam pendentes; mestre aprova e bloqueia, e as regras Firestore impedem acesso dos não autorizados.
- Manter formulários de clientes atuais, pesquisa, edição, cadastro de responsável legal, telefone e dados essenciais. Revisar os campos contra a transcrição **efetivamente verificada** do áudio original; não afirmar que campos não confirmados foram exigidos no áudio.
- Evitar armazenamento de cadastros sensíveis em localStorage ou logs, limitar exportação à conta mestre, implementar saneamento de HTML, regras de segurança, testes de uso nos vários tamanhos de tela e análise LGPD antes de usar dados reais.

## Critérios de aceite

1. Funciona sem Cloud Functions, envio de e-mails de agendamento ou assinatura paga.
2. Lembrete padrão desligado. Ativar **1 dia antes** em um agendamento faz o sino aparecer no dia anterior quando o usuário acessa o site.
3. Badge exibe contagem de não lidos; painel mostra cliente, horário, data e ação para abrir o compromisso.
4. Marcando como lido, o contador diminui. A leitura persiste ao recarregar, somente para a conta em questão; alterações da consulta geram nova oportunidade de lembrete.
5. Consultas de hoje aparecem na aba Hoje, inclusive quando não houve configuração de lembrete.
6. Cancelados/concluídos não exibem lembretes pendentes. Ao sair ou bloquear usuário, nenhum dado de paciente permanece visível na interface.
7. Utilizável por teclado e em dispositivos de 360, 768, 1024 e 1440 pixels.
8. Entregar código legível, regras atualizadas, documentação de deploy Firebase Spark e instruções GitHub.

Referências: https://firebase.google.com/docs/projects/billing/firebase-pricing-plans ; https://firebase.google.com/docs/firestore/query-data/listen ; https://support.google.com/calendar/answer/37242?hl=pt-BR
