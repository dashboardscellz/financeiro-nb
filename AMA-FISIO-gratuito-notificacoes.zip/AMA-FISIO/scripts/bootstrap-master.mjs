/**
 * EXECUTE EM AMBIENTE DE CONFIANÇA (computador da administradora).
 * Credenciais devem chegar por variáveis de ambiente, jamais pelo GitHub.
 * Requer GOOGLE_APPLICATION_CREDENTIALS apontando para a chave de serviço Firebase.
 * Exemplo (bash):
 *   export GOOGLE_APPLICATION_CREDENTIALS='/caminho/credencial.json'
 *   export MASTER_EMAIL='amanda@seudominio.com'
 *   read -rsp 'Senha mestre: ' MASTER_PASSWORD; echo; export MASTER_PASSWORD
 *   npm run bootstrap:master
 */
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

const email = process.env.MASTER_EMAIL?.trim().toLowerCase();
const password = process.env.MASTER_PASSWORD;
if (!process.env.GOOGLE_APPLICATION_CREDENTIALS || !email || !password || password.length < 8) {
  console.error('Informe GOOGLE_APPLICATION_CREDENTIALS, MASTER_EMAIL e MASTER_PASSWORD (mínimo de 8 caracteres).');
  process.exit(1);
}
initializeApp({ credential: applicationDefault() });
const auth = getAuth();
const db = getFirestore();
let user;
try {
  user = await auth.getUserByEmail(email);
  console.log('Usuário mestre existente localizado. A senha atual NÃO será alterada.');
} catch (err) {
  if (err.code !== 'auth/user-not-found') throw err;
  user = await auth.createUser({ email, password, displayName: 'Amanda Marinho', emailVerified: true });
  console.log('Conta mestre criada com segurança.');
}
await auth.setCustomUserClaims(user.uid, { master: true });
await db.doc(`users/${user.uid}`).set({
  name: 'Amanda Marinho', email, role: 'master', status: 'active',
  createdAt: FieldValue.serverTimestamp()
}, { merge: true });
console.log(`Permissão mestre aplicada ao UID ${user.uid}. Configure masterEmail em config.js com ${email}.`);
console.log('Observação: ao alterar permissões, entre novamente para renovar o token.');
